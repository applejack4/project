package com.example.project.Model

class ImageModel(var Image : String ?= null,
                 var date : String ?= null,
                 var time : String ?= null)