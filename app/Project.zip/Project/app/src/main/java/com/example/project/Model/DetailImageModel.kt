package com.example.project.Model

class DetailImageModel(var Image : String ?= null,
                       var date : String ?= null,
                       var time : String ?= null,
                       var name : String ?= null,
                       var clinic : String ?= null)