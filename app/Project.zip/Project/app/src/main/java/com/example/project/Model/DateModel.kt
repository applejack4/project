package com.example.project.Model

class DateModel(var Date_Today : String ?= null)