package com.example.project.Model

class ReviewMode(var name : String ?= null,  var review : String ?= null, var profilePic : String ?= null)