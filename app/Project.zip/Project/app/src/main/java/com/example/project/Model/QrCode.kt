package com.example.project.Model

class QrCode( var qr : String ?= null)