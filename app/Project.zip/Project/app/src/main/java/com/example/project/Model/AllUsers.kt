package com.example.project.Model

class AllUsers(var id : String,
                    var default_number: String)