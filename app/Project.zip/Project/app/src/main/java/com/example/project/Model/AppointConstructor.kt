package com.example.project.Model

class AppointConstructor ( var id : String ?= null,
                                var name : String ?= null,
                                var mobile : String ?= null,
                                var profilePic : String ?= null,
                                var Time : String ?= null,
                           var date : String ?= null)