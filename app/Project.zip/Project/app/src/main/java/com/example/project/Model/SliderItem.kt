package com.example.project.Model

class SliderItem internal constructor(
    val image : Int
)