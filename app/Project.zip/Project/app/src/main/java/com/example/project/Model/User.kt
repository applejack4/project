package com.example.project.Model

class User (var id : String ?= null,
            var firstname : String ?= null,
            var email : String ?= null,
            var mobile : String ?= null,
            var password : String ?= null,
            var profilePicture : String ?= null,
            var token : String ?= null)